/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     | Website:  https://openfoam.org
    \\  /    A nd           | Copyright (C) 2011-2018 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

\*---------------------------------------------------------------------------*/

#include "eddy.H"

// * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * * * //

Foam::eddy::eddy()
:
    shape_("tent"),
    patchFaceI_(-1),
    position0_(vector::zero),
    dist_(0),
    convectVelocity_(0),
    eddySize_u_(vector::zero),
    eddySize_v_(vector::zero),
    eddySize_w_(vector::zero),
    epsilon_(vector::zero),
    Lund_(tensor::zero)
{}


Foam::eddy::eddy
(
    const word shape,
    const label patchFaceI,
    const point& position0,
    const scalar dist,
    const scalar convectVelocity,
    const vector eddySize_u,
    const vector eddySize_v,
    const vector eddySize_w,
    const symmTensor& R,
    Random& rndGen
)
:
    shape_(shape),
    patchFaceI_(patchFaceI),
    position0_(position0),
    dist_(dist),
    convectVelocity_(convectVelocity),
    eddySize_u_(eddySize_u),
    eddySize_v_(eddySize_v),
    eddySize_w_(eddySize_w),
    epsilon_(epsilon(rndGen)),
    Lund_(tensor::zero)
{
    Lund_.replace(tensor::XX, sqrt(R.component(symmTensor::XX)));
    Lund_.replace(tensor::YX, R.component(symmTensor::XY)/Lund_.component(tensor::XX));
    Lund_.replace(tensor::ZX, R.component(symmTensor::XZ)/Lund_.component(tensor::XX));
    Lund_.replace(tensor::YY, sqrt(R.component(symmTensor::YY)-sqr(Lund_.component(tensor::YX))));
    Lund_.replace(tensor::ZY, (R.component(symmTensor::YZ) - Lund_.component(tensor::YX)*Lund_.component(tensor::ZX) )/Lund_.component(tensor::YY));
    Lund_.replace(tensor::ZZ, sqrt(R.component(symmTensor::ZZ) - sqr(Lund_.component(tensor::ZX))-sqr(Lund_.component(tensor::ZY))));
}


Foam::eddy::eddy(const eddy& e)
:
    shape_(e.shape_),
    patchFaceI_(e.patchFaceI_),
    position0_(e.position0_),
    dist_(e.dist_),
    convectVelocity_(e.convectVelocity_),
    eddySize_u_(e.eddySize_u_),
    eddySize_v_(e.eddySize_v_),
    eddySize_w_(e.eddySize_w_),
    epsilon_(e.epsilon_),
    Lund_(e.Lund_)
{}


// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

Foam::vectorField Foam::eddy::uFluct(const pointField& xp) const
{
    vectorField uFluct(xp.size(), vector::zero);

    if (shape_ == "tent")
    {
        forAll(uFluct, label)
        {
            const vector r_u = cmptDivide(cmptMag(xp[label]-position()), eddySize_u_);
            const vector r_v = cmptDivide(cmptMag(xp[label]-position()), eddySize_v_);
            const vector r_w = cmptDivide(cmptMag(xp[label]-position()), eddySize_w_);

            vector u = vector::zero;

            if (r_u.component(0)<1&&r_u.component(1)<1&&r_u.component(2)<1)
            {
                u.component(0) = epsilon_.component(0)*sqrt(3.375)*(1.0-r_u.component(0))*(1.0-r_u.component(1))*(1.0-r_u.component(2))
                               / sqrt(cmptProduct(eddySize_u_));
           }

            if (r_v.component(0)<1&&r_v.component(1)<1&&r_v.component(2)<1)
            {
                u.component(1) = epsilon_.component(1)*sqrt(3.375)*(1.0-r_v.component(0))*(1.0-r_v.component(1))*(1.0-r_v.component(2))
                               / sqrt(cmptProduct(eddySize_v_));
           }

            if (r_w.component(0)<1&&r_w.component(1)<1&&r_w.component(2)<1)
            {
                u.component(2) = epsilon_.component(2)*sqrt(3.375)*(1.0-r_w.component(0))*(1.0-r_w.component(1))*(1.0-r_w.component(2))
                               / sqrt(cmptProduct(eddySize_w_));
           }

           uFluct[label] = Lund_&u;
        }
    }
    else if (shape_ == "step")
    {
        forAll(uFluct, label)
        {
            const vector r_u = cmptDivide(cmptMag(xp[label]-position()), eddySize_u_);
            const vector r_v = cmptDivide(cmptMag(xp[label]-position()), eddySize_v_);
            const vector r_w = cmptDivide(cmptMag(xp[label]-position()), eddySize_w_);

            vector u = vector::zero;

            if (r_u.component(0)<1&&r_u.component(1)<1&&r_u.component(2)<1)
            {
                u.component(0) = epsilon_.component(0)*sqrt(0.125)/sqrt(cmptProduct(eddySize_u_));
            }

            if (r_v.component(0)<1&&r_v.component(1)<1&&r_v.component(2)<1)
            {
                u.component(1) = epsilon_.component(1)*sqrt(0.125)/sqrt(cmptProduct(eddySize_v_));
            }

            if (r_w.component(0)<1&&r_w.component(1)<1&&r_w.component(2)<1)
            {
                u.component(2) = epsilon_.component(2)*sqrt(0.125)/sqrt(cmptProduct(eddySize_w_));
            }
 
            uFluct[label] = Lund_&u;
        }
    }
    else if (shape_ == "gaussian")
    {
        forAll(uFluct, label)
        {
            const vector r_u = cmptDivide(cmptMag(xp[label]-position()), eddySize_u_);
            const vector r_v = cmptDivide(cmptMag(xp[label]-position()), eddySize_v_);
            const vector r_w = cmptDivide(cmptMag(xp[label]-position()), eddySize_w_);

            vector u = vector::zero;

            if (r_u.component(0)<1&&r_u.component(1)<1&&r_u.component(2)<1)
            {
                u.component(0) = epsilon_.component(0)*1.3010*1.3010*1.3010*exp(-4.5*mag(r_u)*mag(r_u))/sqrt(cmptProduct(eddySize_u_));   
            }

            if (r_v.component(0)<1&&r_v.component(1)<1&&r_v.component(2)<1)
            {
                u.component(1) = epsilon_.component(1)*1.3010*1.3010*1.3010*exp(-4.5*mag(r_v)*mag(r_v))/sqrt(cmptProduct(eddySize_v_));   
            }

            if (r_w.component(0)<1&&r_w.component(1)<1&&r_w.component(2)<1)
            {
                u.component(2) = epsilon_.component(2)*1.3010*1.3010*1.3010*exp(-4.5*mag(r_w)*mag(r_w))/sqrt(cmptProduct(eddySize_w_));   
            }

            uFluct[label] = Lund_&u;
        }
    }
    else
    {
        Info << "shape" << shape_ 
             << "does not exist (ERROR)" << endl;
    }
    return uFluct;
}

// ************************************************************************* //
