/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     | Website:  https://openfoam.org
    \\  /    A nd           | Copyright (C) 2011-2018 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

\*---------------------------------------------------------------------------*/

#include "transform.H"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

namespace Foam
{

template<class Type>
tmp<Field<Type>>
digitalFilterFvPatchVectorField::calculateOrRead
(
    const word& fieldName,
    const dictionary& dict,
    bool& calculateField
) const
{
    if (dict.found(fieldName))
    {
        tmp<Field<Type>> tFld
        (
            new Field<Type>
            (
                fieldName,
                dict,
                this->patch().size()
            )
        );
        calculateField = false;
        return tFld;
    }
    else
    {
        calculateField = true;
        return calculateBoundaryData<Type>(fieldName, dict);
    }
}


template<class Type>
tmp<Field<Type>>
digitalFilterFvPatchVectorField::calculateBoundaryData
(
    const word& fieldName,
    const dictionary& dict
) const
{
    word subDictName(fieldName+"Dict");
    Field<Type> value(this->patch().size(), pTraits<Type>::zero);

    if (dict.found(subDictName))
    {
        const dictionary& subDict = dict.subDict(subDictName);

        word profile(subDict.lookupOrDefault<word>("profile", "uniform"));
        Type referenceValue(subDict.lookupOrDefault<Type>("referenceValue", pTraits<Type>::zero));

        if (profile == "uniform")
        {
            value = referenceValue;
        }
        else if (profile == "exponential")
        {
            vectorField fCentres(transform()&this->patch().Cf());
            fCentres = fCentres-originOfLocalCoord();

            const scalar refAngl(subDict.lookupOrDefault<scalar>("referenceAngl", 0.0));
            const scalar refDist(subDict.lookupOrDefault<scalar>("referenceDist", 1.0));

            vector refDire(vector::zero);
            refDire.component(vector::Y) = ::sin(refAngl*constant::mathematical::twoPi/360);
            refDire.component(vector::Z) = ::cos(refAngl*constant::mathematical::twoPi/360);

            if (refDist <= 0)
            {
                Info<<"reference distance of the " << fieldName << " field is no larger than zero (ERROR)" << endl;
            }

            const scalarField dirCmpt((refDire&fCentres)/refDist);

            Type alpha(subDict.lookupOrDefault<Type>("alpha", pTraits<Type>::zero));

            forAll(value, label)
            {
                value[label] = cmptMultiply
                (
                    referenceValue,
                    cmptPow(pTraits<Type>::one*fabs(dirCmpt[label]), alpha)
                );
            }
        }
        else
        {
            Info << "profile " << profile << " does not exist (ERROR)" << endl;
        }
    }
    else
    {
        Info << "parameters for " << fieldName << " does not exist (ERROR)" << endl;
    }

    tmp<Field<Type>> tFld(new Field<Type>(value));

    return tFld;
}

template<>
tmp<symmTensorField>
Foam::digitalFilterFvPatchVectorField::calculateBoundaryData<symmTensor>
(
    const word& fieldName,
    const dictionary& dict
) const
{
    word subDictName(fieldName+"Dict");
    symmTensorField value(this->patch().size(),symmTensor::zero);

    if (dict.found(subDictName))
    {
        const dictionary& subDict = dict.subDict(subDictName);

        word profile(subDict.lookupOrDefault<word>("profile", "uniform"));
        symmTensor referenceValue(subDict.lookupOrDefault<symmTensor>("referenceValue", symmTensor::zero));

        if (profile == "uniform")
        {
            value = referenceValue;
        }
        else if (profile == "exponential")
        {
            vectorField fCentres(transform()&this->patch().Cf());
            fCentres = fCentres-originOfLocalCoord();

            const scalar refAngl(subDict.lookupOrDefault<scalar>("referenceAngl", 0.0));
            const scalar refDist(subDict.lookupOrDefault<scalar>("referenceDist", 1.0));

            vector refDire(vector::zero);
            refDire.component(vector::Y) = ::sin(refAngl*constant::mathematical::twoPi/360);
            refDire.component(vector::Z) = ::cos(refAngl*constant::mathematical::twoPi/360);

            if (refDist <= 0)
            {
                Info<<"reference distance of the " << fieldName << " field is no larger than zero (ERROR)" << endl;
            }

            const scalarField dirCmpt((refDire&fCentres)/refDist);

            Info<< referenceValue << endl;

            vector eigenVal = eigenValues(referenceValue);
            tensor eigenVec = eigenVectors(referenceValue);

            Info<< eigenVal << endl;
            Info<< eigenVec << endl;

            vector a1(eigenVec.component(tensor::XX),eigenVec.component(tensor::XY),eigenVec.component(tensor::XZ));
            vector a2(eigenVec.component(tensor::YX),eigenVec.component(tensor::YY),eigenVec.component(tensor::YZ));
            vector a3(eigenVec.component(tensor::ZX),eigenVec.component(tensor::ZY),eigenVec.component(tensor::ZZ));

            symmTensor M1(a1[0]*a1[0],a1[0]*a1[1],a1[0]*a1[2],a1[1]*a1[1],a1[1]*a1[2],a1[2]*a1[2]);
            symmTensor M2(a2[0]*a2[0],a2[0]*a2[1],a2[0]*a2[2],a2[1]*a2[1],a2[1]*a2[2],a2[2]*a2[2]);
            symmTensor M3(a3[0]*a3[0],a3[0]*a3[1],a3[0]*a3[2],a3[1]*a3[1],a3[1]*a3[2],a3[2]*a3[2]);

            M1 = M1*eigenVal[0];
            M2 = M2*eigenVal[1];
            M3 = M3*eigenVal[2];

            vector alpha(subDict.lookupOrDefault<vector>("alpha", vector::zero));

            forAll(value, label)
            {
                vector powCoef(cmptPow(vector::one*fabs(dirCmpt[label]), alpha));
                value[label] = powCoef[0]*M1+powCoef[1]*M2+powCoef[2]*M3;
            }
        }
        else
        {
            Info << "profile " << profile << " does not exist (ERROR)" << endl;
        }
    }
    else
    {
        Info << "parameters for " << fieldName << " does not exist (ERROR)" << endl;
    }

    tmp<symmTensorField> tFld(new symmTensorField(value));

    return tFld;
}

template<class Type>
Field<Type>
digitalFilterFvPatchVectorField::gatherProc
(
    const Field<Type>& valsProc
) const
{
    List<Field<Type>> vals;
    vals.setSize(Pstream::nProcs());
    vals[Pstream::myProcNo()] = valsProc;

    Pstream::gatherList(vals);
    Pstream::scatterList(vals);

    return ListListOps::combine<Field<Type>>(vals, accessOp<Field<Type>>());
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

} // End namespace Foam

// ************************************************************************* //
