/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     | Website:  https://openfoam.org
    \\  /    A nd           | Copyright (C) 2011-2018 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

\*---------------------------------------------------------------------------*/

#include "syntheticEddyFvPatchVectorField.H"
#include "volFields.H"
#include "addToRunTimeSelectionTable.H"
#include "fvPatchFieldMapper.H"
#include "momentOfInertia.H"
#include "globalIndex.H"
#include "IFstream.H"
#include "OFstream.H"

// * * * * * * * * * * * * * * Static Data Members * * * * * * * * * * * * * //

Foam::label Foam::syntheticEddyFvPatchVectorField::seedIterMax_ = 1000;
Foam::scalar Foam::syntheticEddyFvPatchVectorField::lengthRatioMin_ = 0.5;

// * * * * * * * * * * * * * Private Member Functions  * * * * * * * * * * * //

void Foam::syntheticEddyFvPatchVectorField::initialisePatch()
{
    const vectorField nf(patch().nf());

    // Patch normal points into domain
    patchNormal_ = -gAverage(nf);

    // Check that patch is planar
    scalar error = max(magSqr(patchNormal_ + nf));

    if (error > SMALL)
    {
        WarningInFunction
            << "Patch " << patch().name() << " is not planar"
            << endl;
    }

    forAll (patchNormal_, label)
    {
        if (mag(patchNormal_[label]) <= SMALL)
        {
            patchNormal_[label] = 0;
        }
    }

    vector yDirection(vector::zero);
    vector zDirection(vector::zero);

    if (mag(intersection_) > 0)
    {
        intersection_ /= mag(intersection_);
        zDirection = patchNormal_^intersection_;

        if (mag(zDirection) == 0)
        {
            zDirection = vector(0,0,1);
        }
    }
    else
    {
        zDirection = vector(0,0,1);
    }

    yDirection = zDirection^patchNormal_;

    if (mag(intersection_) > 0)
    {
        vector eulerAngle(vector::zero);

        eulerAngle[0] = ::acos(vector(1,0,0)&intersection_);
        tensor T1 = tensor(::cos(eulerAngle[0]),::sin(eulerAngle[0]),0,-::sin(eulerAngle[0]),::cos(eulerAngle[0]),0,0,0,1);
        scalar sign = (T1&vector(1,0,0))&intersection_;

        if (sign < 0)
        {
            eulerAngle[0] = -eulerAngle[0];
            T1 = tensor(::cos(eulerAngle[0]),::sin(eulerAngle[0]),0,-::sin(eulerAngle[0]),::cos(eulerAngle[0]),0,0,0,1);
        }

        eulerAngle[1] = ::acos(vector(0,0,1)&zDirection);
        tensor T2 = tensor(1,0,0,0,::cos(eulerAngle[1]),::sin(eulerAngle[1]),0,-::sin(eulerAngle[1]),::cos(eulerAngle[1]));
        sign = (T2&vector(0,0,1))&zDirection;

        if (sign < 0)
        {
            eulerAngle[1] = -eulerAngle[1];
            T2 = tensor(1,0,0,0,::cos(eulerAngle[1]),::sin(eulerAngle[1]),0,-::sin(eulerAngle[1]),::cos(eulerAngle[1]));
        }
    
        eulerAngle[2] = ::acos(patchNormal_&intersection_);
        tensor T3 = tensor(::cos(eulerAngle[2]),::sin(eulerAngle[2]),0,-::sin(eulerAngle[2]),::cos(eulerAngle[2]),0,0,0,1);
        sign = (T3&intersection_)&patchNormal_;

        if (sign < 0)
        {
            eulerAngle[2] = -eulerAngle[2];
            T3 = tensor(::cos(eulerAngle[2]),::sin(eulerAngle[2]),0,-::sin(eulerAngle[2]),::cos(eulerAngle[2]),0,0,0,1);
        }
    
        transform_ = T3&(T2&T1);
    }
    else
    {
        scalar eulerAngle = ::acos(vector(1,0,0)&patchNormal_);
        tensor T1 = tensor(::cos(eulerAngle),::sin(eulerAngle),0,-::sin(eulerAngle),::cos(eulerAngle),0,0,0,1);
        scalar sign = (T1&vector(1,0,0))&patchNormal_;

        if (sign < 0)
        {
            eulerAngle = -eulerAngle;
            T1 = tensor(::cos(eulerAngle),::sin(eulerAngle),0,-::sin(eulerAngle),::cos(eulerAngle),0,0,0,1);
        }

        transform_ = T1;
    }

    forAll (transform_, label)
    {
        if (mag(transform_[label]) <= SMALL)
        {
            transform_[label] = 0;
        }
    }

    // Decompose the patch faces into triangles to enable point search

    const fvBoundaryMesh& boundaryMesh = patch().boundaryMesh();
    const fvMesh& mesh = boundaryMesh.mesh();
    const faceList& fs = mesh.faces();

    const polyPatch& polyPatch = this->patch().patch();
    const pointField& points = polyPatch.points();

    label nPoints = 0;

    for (label facei = 0; facei<polyPatch.size(); facei++)
    {
        const labelList& f = fs[facei+polyPatch.start()];
        nPoints += f.size();
    }

    labelList pList(nPoints, 0);
    label start = 0;

    for (label facei = 0; facei<polyPatch.size(); facei++)
    {
        const labelList& f = fs[facei+polyPatch.start()];

        for (label pi = 0; pi < f.size(); pi++)
        {
            pList[pi+start] = f[pi];
        }

        start += f.size();
    }

    labelList uniqueOrderList;
    uniqueOrder(pList, uniqueOrderList);

    labelList pUniqueList(uniqueOrderList.size(), 0);
    vectorField patchPoints(uniqueOrderList.size(), vector::zero);

    forAll(uniqueOrderList, label)
    {
        pUniqueList[label] = pList[uniqueOrderList[label]];
        patchPoints[label] = points[pUniqueList[label]];
    }

    boundBox globalPatchBounds(transform_&patchPoints);

    origin_ = globalPatchBounds.min();
    origin_[1] += yOffset_;
    origin_[2] += zOffset_;

    if (Pstream::master())
    {
        Info<< "local x-axis: " << patchNormal_ << endl;
        Info<< "local y-axis: " << yDirection << endl;
        Info<< "local z-axis: " << zDirection << endl;
        Info<< "global position of the origin of the local coordinate sytem: " << (transform_.T()&origin()) << endl;
        Info<< "coordinates tranform matrix: " << transform_ << endl;
    }

    // Triangulate the patch faces and create addressing
    DynamicList<label> triToFace(2*polyPatch.size());
    DynamicList<scalar> triMagSf(2*polyPatch.size());
    DynamicList<face> triFace(2*polyPatch.size());
    DynamicList<face> tris(5);

    // Set zero value at the start of the tri area list
    triMagSf.append(0.0);

    forAll(polyPatch, faceI)
    {
        const face& f = polyPatch[faceI];

        tris.clear();
        f.triangles(points, tris);

        forAll(tris, i)
        {
            triToFace.append(faceI);
            triFace.append(tris[i]);
            triMagSf.append(tris[i].mag(points));
        }
    }

    forAll(sumTriMagSf_, i)
    {
        sumTriMagSf_[i] = 0.0;
    }

    sumTriMagSf_[Pstream::myProcNo() + 1] = sum(triMagSf);

    Pstream::listCombineGather(sumTriMagSf_, maxEqOp<scalar>());
    Pstream::listCombineScatter(sumTriMagSf_);

    for (label i = 1; i < triMagSf.size(); i++)
    {
        triMagSf[i] += triMagSf[i-1];
    }

    // Transfer to persistent storage
    triFace_.transfer(triFace);
    triToFace_.transfer(triToFace);
    triCumulativeMagSf_.transfer(triMagSf);

    // Convert sumTriMagSf_ into cumulative sum of areas per proc
    for (label i = 1; i < sumTriMagSf_.size(); i++)
    {
        sumTriMagSf_[i] += sumTriMagSf_[i-1];
    }

    // Global patch area (over all processors)
    patchArea_ = sumTriMagSf_.last();

    // Local patch bounds (this processor)
    patchBounds_ = boundBox((transform_&polyPatch.localPoints())-origin(), false);
    patchBounds_.inflate(0.1);

    // Determine if all eddies spawned from a single processor
    singleProc_ = polyPatch.size() == returnReduce(polyPatch.size(), sumOp<label>());
    reduce(singleProc_, orOp<bool>());
}

void Foam::syntheticEddyFvPatchVectorField::initialiseParameters()
{
    U_ = calculateOrRead<scalar>("U", inflowProperties_, calculateU_);
    I_ = calculateOrRead<symmTensor>("I", inflowProperties_, calculateI_);
    R_ = U_*I_;

    forAll(R_, label)
    {
        R_[label].component(symmTensor::XX) = R_[label].component(symmTensor::XX)*R_[label].component(symmTensor::XX);
        R_[label].component(symmTensor::YY) = R_[label].component(symmTensor::YY)*R_[label].component(symmTensor::YY);
        R_[label].component(symmTensor::ZZ) = R_[label].component(symmTensor::ZZ)*R_[label].component(symmTensor::ZZ);
        R_[label].component(symmTensor::XY) = R_[label].component(symmTensor::XY)*R_[label].component(symmTensor::XY)*sign(I_[label].component(symmTensor::XY));
        R_[label].component(symmTensor::YZ) = R_[label].component(symmTensor::YZ)*R_[label].component(symmTensor::YZ)*sign(I_[label].component(symmTensor::YZ));
        R_[label].component(symmTensor::XZ) = R_[label].component(symmTensor::XZ)*R_[label].component(symmTensor::XZ)*sign(I_[label].component(symmTensor::XZ));
    }

    Lux_ = calculateOrRead<scalar>("Lux", inflowProperties_, calculateL_);
    Lvx_ = calculateOrRead<scalar>("Lvx", inflowProperties_, calculateL_);
    Lwx_ = calculateOrRead<scalar>("Lwx", inflowProperties_, calculateL_);

    const scalar deltaT = db().time().deltaTValue();

    forAll(Lux_, label)
    {
        if (Lux_[label] < U_[label]*deltaT)
        {
            Lux_[label] = U_[label]*deltaT;
        }

        if (Lvx_[label] < U_[label]*deltaT)
        {
            Lvx_[label] = U_[label]*deltaT;
        }

        if (Lwx_[label] < U_[label]*deltaT)
        {
            Lwx_[label] = U_[label]*deltaT;
        }
    }

    if (LuyToLuxRatio_ < lengthRatioMin_)
    {
        LuyToLuxRatio_ = lengthRatioMin_;
    }

    if (LuzToLuxRatio_ < lengthRatioMin_)
    {
        LuzToLuxRatio_ = lengthRatioMin_;
    }

    if (LvyToLvxRatio_ < lengthRatioMin_)
    {
        LvyToLvxRatio_ = lengthRatioMin_;
    }

    if (LvzToLvxRatio_ < lengthRatioMin_)
    {
        LvzToLvxRatio_ = lengthRatioMin_;
    }

    if (LwyToLwxRatio_ < lengthRatioMin_)
    {
        LwyToLwxRatio_ = lengthRatioMin_;
    }

    if (LwzToLwxRatio_ < lengthRatioMin_)
    {
        LwzToLwxRatio_ = lengthRatioMin_;
    }

    UMax_ = gMax(U_);
}

void Foam::syntheticEddyFvPatchVectorField::initialiseEddyBox()
{
    const scalarField& magSf = patch().magSf();

    // Maximum extent across all processors
    maxEddySize_ = cmptMax(vector(gMax(Lux_),gMax(Lvx_),gMax(Lwx_)));

    // Eddy box volume
    V0_ = 2*gSum(magSf)*maxEddySize_;

    {
        Info<< "Patch: " << patch().patch().name() << nl
            << "eddy box volume: " << V0_ << nl
            << "maximum eddy size: " << maxEddySize_ << nl
            << endl;
    }
}


Foam::pointIndexHit Foam::syntheticEddyFvPatchVectorField::setNewPosition
(
    const bool global
)
{
    // Initialise to miss
    pointIndexHit pos(false, vector::max, -1);

    const polyPatch& polyPatch = this->patch().patch();
    const pointField& points = polyPatch.points();

    if (global)
    {
        scalar areaFraction = patchArea_*rndGen_.globalScalar01();

        // Determine which processor to use
        label procI = 0;

        forAllReverse(sumTriMagSf_, i)
        {
            if (areaFraction >= sumTriMagSf_[i])
            {
                procI = i;
                break;
            }
        }

        if (Pstream::myProcNo() == procI)
        {
            // Find corresponding decomposed face triangle
            label triI = 0;
            scalar offset = sumTriMagSf_[procI];
            forAllReverse(triCumulativeMagSf_, i)
            {
                if (areaFraction > triCumulativeMagSf_[i] + offset)
                {
                    triI = i;
                    break;
                }
            }

            // Find random point in triangle
            const face& tf = triFace_[triI];
            const triPointRef tri(points[tf[0]], points[tf[1]], points[tf[2]]);

            pos.setHit();
            pos.setIndex(triToFace_[triI]);
            pos.rawPoint() = tri.randomPoint(rndGen_);
        }
    }
    else
    {
        // Find corresponding decomposed face triangle on local processor
        label triI = 0;
        scalar maxAreaLimit = triCumulativeMagSf_.last();
        scalar areaFraction = maxAreaLimit*rndGen_.scalar01();

        forAllReverse(triCumulativeMagSf_, i)
        {
            if (areaFraction > triCumulativeMagSf_[i])
            {
                triI = i;
                break;
            }
        }

        // Find random point in triangle
        const face& tf = triFace_[triI];
        const triPointRef tri(points[tf[0]], points[tf[1]], points[tf[2]]);

        pos.setHit();
        pos.setIndex(triToFace_[triI]);
        pos.rawPoint() = tri.randomPoint(rndGen_);
    }

    return pos;
}


void Foam::syntheticEddyFvPatchVectorField::initialiseEddies()
{
    DynamicList<eddy> eddies(size());

    // Initialise eddy properties
    scalar sumVolEddy = 0;
    scalar sumVolEddyAllProc = 0;
    scalar eddySizeRatio = eddySizeToLengthscaleRatio();

    while (sumVolEddyAllProc/V0_ < eddyDensity_)
    {
        // Get new parallel consistent position
        pointIndexHit pos(setNewPosition(true));
        label faceI = pos.index();

        // Note: only 1 processor will pick up this face
        if (faceI != -1)
        {
            eddy e
            (
                eddyShape_,
                faceI,
                (transform()&pos.hitPoint())-origin(),
                rndGen_.scalarAB(-maxEddySize_, maxEddySize_),
                U_[faceI],
                eddySizeRatio*vector(Lux_[faceI],Lux_[faceI]*LuyToLuxRatio_,Lux_[faceI]*LuzToLuxRatio_),
                eddySizeRatio*vector(Lvx_[faceI],Lvx_[faceI]*LvyToLvxRatio_,Lvx_[faceI]*LvzToLvxRatio_),
                eddySizeRatio*vector(Lwx_[faceI],Lwx_[faceI]*LwyToLwxRatio_,Lwx_[faceI]*LwzToLwxRatio_),
                R_[faceI],
                rndGen_
            );

            eddies.append(e);
            sumVolEddy += e.volume();
        }

        sumVolEddyAllProc = returnReduce(sumVolEddy, sumOp<scalar>());
    }

    eddies_.transfer(eddies);
    nEddy_ = eddies_.size();

    if (debug)
    {
        Pout<< "Patch:" << patch().patch().name();

        if (Pstream::parRun())
        {
            Pout<< " processor:" << Pstream::myProcNo();
        }

        Pout<< " seeded:" << nEddy_ << " eddies" << endl;
    }

    reduce(nEddy_, sumOp<label>());

    if (nEddy_ > 0)
    {
        Info<< "synthetic eddy patch: " << patch().name()
            << " seeded " << nEddy_ << " eddies with total volume "
            << sumVolEddyAllProc
            << endl;
    }
    else
    {
        WarningInFunction
            << "Patch: " << patch().patch().name()
            << " on field " << internalField().name()
            << ": No eddies seeded - please check your set-up" << endl;
    }
}


void Foam::syntheticEddyFvPatchVectorField::convectEddies
(
    const scalar deltaT
)
{
    // Note: all operations applied to local processor only

    label nRecycled = 0;
    scalar eddySizeRatio = eddySizeToLengthscaleRatio();

    forAll(eddies_, eddyI)
    {
        eddy& e = eddies_[eddyI];
        e.move(deltaT);

        const scalar position0 = e.dist();

        // Check to see if eddy has exited downstream box plane
        if (fabs(position0) > maxEddySize_)
        {
            pointIndexHit pos(setNewPosition(false));
            label faceI = pos.index();

            scalar Uran = rndGen_.scalar01()*UMax();

            label iter = 0;

            while (Uran > mag(U_[faceI]) && iter++ < seedIterMax_)
            {
                pointIndexHit pos(setNewPosition(false));
                faceI = pos.index();
                Uran = rndGen_.scalar01()*UMax();
            }

            e = eddy
            (
                eddyShape_,
                faceI,
                (transform()&pos.hitPoint())-origin(),
                rndGen_.scalar01()*deltaT*U_[faceI]-maxEddySize_,
                U_[faceI],
                eddySizeRatio*vector(Lux_[faceI],Lux_[faceI]*LuyToLuxRatio_,Lux_[faceI]*LuzToLuxRatio_),
                eddySizeRatio*vector(Lvx_[faceI],Lvx_[faceI]*LvyToLvxRatio_,Lvx_[faceI]*LvzToLvxRatio_),
                eddySizeRatio*vector(Lwx_[faceI],Lwx_[faceI]*LwyToLwxRatio_,Lwx_[faceI]*LwzToLwxRatio_),
                R_[faceI],
                rndGen_
            );

            nRecycled++;
        }
    }

    reduce(nRecycled, sumOp<label>());

    if (nRecycled > 0)
    {
        Info<< "Patch: " << patch().patch().name() << " recycled "
            << nRecycled << " eddies" << endl;
    }
}


Foam::vectorField Foam::syntheticEddyFvPatchVectorField::uFluctEddy
(
    const List<eddy>& eddies,
    const pointField& patchFaceCf
) const
{
    vectorField uFluct(patchFaceCf.size(), vector::zero);
    forAll(eddies, k)
    {
        const eddy& e = eddies[k];
        uFluct += e.uFluct(patchFaceCf);
    }
    return uFluct;
}


void Foam::syntheticEddyFvPatchVectorField::calcOverlappingProcEddies
(
    List<List<eddy>>& overlappingEddies
) const
{
    int oldTag = UPstream::msgType();
    UPstream::msgType() = oldTag + 1;

    List<boundBox> patchBBs(Pstream::nProcs());
    patchBBs[Pstream::myProcNo()] = patchBounds_;
    Pstream::gatherList(patchBBs);
    Pstream::scatterList(patchBBs);

    // Per processor indices into all segments to send
    List<DynamicList<label>> dynSendMap(Pstream::nProcs());

    forAll(eddies_, i)
    {
        // Collect overlapping eddies
        const eddy& e = eddies_[i];

        // Eddy bounds
        point x = e.position();
        boundBox ebb = e.bounds();
        ebb.min() += x;
        ebb.max() += x;

        forAll(patchBBs, procI)
        {
            // Not including intersection with local patch
            if (procI != Pstream::myProcNo())
            {
                if (ebb.overlaps(patchBBs[procI]))
                {
                    dynSendMap[procI].append(i);
                }
            }
        }
    }

    labelListList sendMap(Pstream::nProcs());

    forAll(sendMap, procI)
    {
        sendMap[procI].transfer(dynSendMap[procI]);
    }

    // Send the number of eddies for local processors to receive
    labelListList sendSizes(Pstream::nProcs());
    sendSizes[Pstream::myProcNo()].setSize(Pstream::nProcs());

    forAll(sendMap, procI)
    {
        sendSizes[Pstream::myProcNo()][procI] = sendMap[procI].size();
    }

    Pstream::gatherList(sendSizes);
    Pstream::scatterList(sendSizes);

    // Determine order of receiving
    labelListList constructMap(Pstream::nProcs());

    // Local segment first
    constructMap[Pstream::myProcNo()] = identity
    (
        sendMap[Pstream::myProcNo()].size()
    );

    label segmentI = constructMap[Pstream::myProcNo()].size();

    forAll(constructMap, procI)
    {
        if (procI != Pstream::myProcNo())
        {
            // What I need to receive is what other processor is sending to me
            label nRecv = sendSizes[procI][Pstream::myProcNo()];
            constructMap[procI].setSize(nRecv);

            for (label i = 0; i < nRecv; i++)
            {
                constructMap[procI][i] = segmentI++;
            }
        }
    }

    mapDistribute map(segmentI, xferMove(sendMap), xferMove(constructMap));

    PstreamBuffers pBufs(Pstream::commsTypes::nonBlocking);

    for (label domain = 0; domain < Pstream::nProcs(); domain++)
    {
        const labelList& sendElems = map.subMap()[domain];

        if (domain != Pstream::myProcNo() && sendElems.size())
        {
            List<eddy> subEddies(UIndirectList<eddy>(eddies_, sendElems));

            UOPstream toDomain(domain, pBufs);

            toDomain<< subEddies;
        }
    }

    // Start receiving
    pBufs.finishedSends();

    // Consume
    for (label domain = 0; domain < Pstream::nProcs(); domain++)
    {
        const labelList& recvElems = map.constructMap()[domain];

        if (domain != Pstream::myProcNo() && recvElems.size())
        {
            UIPstream str(domain, pBufs);
            {
                str >> overlappingEddies[domain];
            }
        }
    }

    // Restore tag
    UPstream::msgType() = oldTag;

}

Foam::scalar
Foam::syntheticEddyFvPatchVectorField::eddySizeToLengthscaleRatio() const
{
    if (eddyShape_ == "tent")
    {
        return 4.0/3.0;
    }
    else if (eddyShape_ == "step")
    {
        return 1.0;
    }
    else if (eddyShape_ == "gaussian")
    {
        const scalar pi = constant::mathematical::pi;
        return sqrt(9.0/pi);
    }
    else
    {
        Info << "velocity shape " << eddyShape_ << "does not exist (ERROR)" << endl;
        return 0;
    }
}


// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

Foam::syntheticEddyFvPatchVectorField::
syntheticEddyFvPatchVectorField
(
    const fvPatch& p,
    const DimensionedField<vector, volMesh>& iF
)
:
    fixedValueFvPatchField<vector>(p, iF),

    patchNormal_(vector::zero),
    patchBounds_(boundBox::invertedBox),
    patchArea_(-1),
    triFace_(),
    triToFace_(),
    triCumulativeMagSf_(),
    sumTriMagSf_(Pstream::nProcs() + 1, 0.0),
    intersection_(vector::zero),
    origin_(vector::zero),
    yOffset_(0),
    zOffset_(0),
    transform_(tensor::I),

    inflowProperties_(),
    calculateU_(false),
    calculateI_(false),
    calculateL_(false),
    U_(p.size(), 0.0),
    UMax_(0.0),
    I_(p.size(), pTraits<symmTensor>::zero),
    R_(p.size(), pTraits<symmTensor>::zero),
    Lux_(p.size(), 0.0),
    Lvx_(p.size(), 0.0),
    Lwx_(p.size(), 0.0),
    LuyToLuxRatio_(1.0),
    LuzToLuxRatio_(1.0),
    LvyToLvxRatio_(1.0),
    LvzToLvxRatio_(1.0),
    LwyToLwxRatio_(1.0),
    LwzToLwxRatio_(1.0),

    V0_(0),
    eddyDensity_(1),
    nEddy_(0),
    eddies_(0),
    eddyShape_("gaussian"),
    rndGen_((Pstream::myProcNo()+1)*time(NULL)),
    maxEddySize_(0),
    singleProc_(false)
{}

Foam::syntheticEddyFvPatchVectorField::
syntheticEddyFvPatchVectorField
(
    const fvPatch& p,
    const DimensionedField<vector, volMesh>& iF,
    const dictionary& dict
)
:
    fixedValueFvPatchField<vector>(p, iF, dict),
    curTimeIndex_(-1),

    patchNormal_(vector::zero),
    patchBounds_(boundBox::invertedBox),
    patchArea_(-1),
    triFace_(),
    triToFace_(),
    triCumulativeMagSf_(),
    sumTriMagSf_(Pstream::nProcs() + 1, 0.0),
    intersection_(dict.lookupOrDefault<vector>("intersection", vector(0,0,0))),
    origin_(vector::zero),
    yOffset_(dict.lookupOrDefault<scalar>("yOffset", 0.0)),
    zOffset_(dict.lookupOrDefault<scalar>("zOffset", 0.0)),
    transform_(tensor::I),

    inflowProperties_
    (
        IOdictionary
        (
            IOobject
            (
                "inflowProperties",
                internalField().mesh().time().constant(),
                internalField().mesh(),
                IOobject::MUST_READ_IF_MODIFIED,
                IOobject::NO_WRITE,
                false
            )
        )
    ),
    calculateU_(false),
    calculateI_(false),
    calculateL_(false),
    U_(p.size(), 0.0),
    I_(p.size(), pTraits<symmTensor>::zero),
    R_(p.size(), pTraits<symmTensor>::zero),
    Lux_(p.size(), 0.0),
    Lvx_(p.size(), 0.0),
    Lwx_(p.size(), 0.0),
    LuyToLuxRatio_(inflowProperties_.lookupOrDefault<scalar>("LuyToLuxRatio", 1.0)),
    LuzToLuxRatio_(inflowProperties_.lookupOrDefault<scalar>("LuzToLuxRatio", 1.0)),
    LvyToLvxRatio_(inflowProperties_.lookupOrDefault<scalar>("LvyToLvxRatio", 1.0)),
    LvzToLvxRatio_(inflowProperties_.lookupOrDefault<scalar>("LvzToLvxRatio", 1.0)),
    LwyToLwxRatio_(inflowProperties_.lookupOrDefault<scalar>("LwyToLwxRatio", 1.0)),
    LwzToLwxRatio_(inflowProperties_.lookupOrDefault<scalar>("LwzToLwxRatio", 1.0)),

    V0_(0),
    eddyDensity_(dict.lookupOrDefault<scalar>("eddyDensity", 1)),
    nEddy_(0),
    eddies_(),
    eddyShape_(dict.lookupOrDefault<word>("eddyShape", "gaussian")),
    rndGen_((Pstream::myProcNo()+1)*time(NULL)),
    maxEddySize_(0),
    singleProc_(false)
{}


Foam::syntheticEddyFvPatchVectorField::
syntheticEddyFvPatchVectorField
(
    const syntheticEddyFvPatchVectorField& ptf,
    const fvPatch& p,
    const DimensionedField<vector, volMesh>& iF,
    const fvPatchFieldMapper& mapper
)
:
    fixedValueFvPatchField<vector>(ptf, p, iF, mapper),
    curTimeIndex_(-1),

    patchNormal_(ptf.patchNormal_),
    patchBounds_(ptf.patchBounds_),
    patchArea_(ptf.patchArea_),
    triFace_(ptf.triFace_),
    triToFace_(ptf.triToFace_),
    triCumulativeMagSf_(ptf.triCumulativeMagSf_),
    sumTriMagSf_(ptf.sumTriMagSf_),
    intersection_(ptf.intersection_),
    origin_(ptf.origin_),
    yOffset_(ptf.yOffset_),
    zOffset_(ptf.zOffset_),
    transform_(ptf.transform_),

    inflowProperties_(ptf.inflowProperties_),
    calculateU_(ptf.calculateU_),
    calculateI_(ptf.calculateI_),
    calculateL_(ptf.calculateL_),
    U_(ptf.U_),
    UMax_(ptf.UMax_),
    I_(ptf.I_),
    R_(ptf.R_),
    Lux_(ptf.Lux_),
    Lvx_(ptf.Lvx_),
    Lwx_(ptf.Lwx_),
    LuyToLuxRatio_(ptf.LuyToLuxRatio_),
    LuzToLuxRatio_(ptf.LuzToLuxRatio_),
    LvyToLvxRatio_(ptf.LvyToLvxRatio_),
    LvzToLvxRatio_(ptf.LvzToLvxRatio_),
    LwyToLwxRatio_(ptf.LwyToLwxRatio_),
    LwzToLwxRatio_(ptf.LwzToLwxRatio_),

    V0_(ptf.V0_),
    eddyDensity_(ptf.eddyDensity_),
    nEddy_(ptf.nEddy_),
    eddies_(ptf.eddies_),
    eddyShape_(ptf.eddyShape_),
    rndGen_(ptf.rndGen_),
    maxEddySize_(ptf.maxEddySize_),
    singleProc_(ptf.singleProc_)
{}


Foam::syntheticEddyFvPatchVectorField::
syntheticEddyFvPatchVectorField
(
    const syntheticEddyFvPatchVectorField& ptf
)
:
    fixedValueFvPatchField<vector>(ptf),
    curTimeIndex_(-1),

    patchNormal_(ptf.patchNormal_),
    patchBounds_(ptf.patchBounds_),
    patchArea_(ptf.patchArea_),
    triFace_(ptf.triFace_),
    triToFace_(ptf.triToFace_),
    triCumulativeMagSf_(ptf.triCumulativeMagSf_),
    sumTriMagSf_(ptf.sumTriMagSf_),
    intersection_(ptf.intersection_),
    origin_(ptf.origin_),
    yOffset_(ptf.yOffset_),
    zOffset_(ptf.zOffset_),
    transform_(ptf.transform_),

    inflowProperties_(ptf.inflowProperties_),
    calculateU_(ptf.calculateU_),
    calculateI_(ptf.calculateI_),
    calculateL_(ptf.calculateL_),
    U_(ptf.U_),
    UMax_(ptf.UMax_),
    I_(ptf.I_),
    R_(ptf.R_),
    Lux_(ptf.Lux_),
    Lvx_(ptf.Lvx_),
    Lwx_(ptf.Lwx_),
    LuyToLuxRatio_(ptf.LuyToLuxRatio_),
    LuzToLuxRatio_(ptf.LuzToLuxRatio_),
    LvyToLvxRatio_(ptf.LvyToLvxRatio_),
    LvzToLvxRatio_(ptf.LvzToLvxRatio_),
    LwyToLwxRatio_(ptf.LwyToLwxRatio_),
    LwzToLwxRatio_(ptf.LwzToLwxRatio_),

    V0_(ptf.V0_),
    eddyDensity_(ptf.eddyDensity_),
    nEddy_(ptf.nEddy_),
    eddies_(ptf.eddies_),
    eddyShape_(ptf.eddyShape_),
    rndGen_(ptf.rndGen_),
    maxEddySize_(ptf.maxEddySize_),
    singleProc_(ptf.singleProc_)
{}


Foam::syntheticEddyFvPatchVectorField::
syntheticEddyFvPatchVectorField
(
    const syntheticEddyFvPatchVectorField& ptf,
    const DimensionedField<vector, volMesh>& iF
)
:
    fixedValueFvPatchField<vector>(ptf),
    curTimeIndex_(-1),

    patchNormal_(ptf.patchNormal_),
    patchBounds_(ptf.patchBounds_),
    patchArea_(ptf.patchArea_),
    triFace_(ptf.triFace_),
    triToFace_(ptf.triToFace_),
    triCumulativeMagSf_(ptf.triCumulativeMagSf_),
    sumTriMagSf_(ptf.sumTriMagSf_),
    intersection_(ptf.intersection_),
    origin_(ptf.origin_),
    yOffset_(ptf.yOffset_),
    zOffset_(ptf.zOffset_),
    transform_(ptf.transform_),

    inflowProperties_(ptf.inflowProperties_),
    calculateU_(ptf.calculateU_),
    calculateI_(ptf.calculateI_),
    calculateL_(ptf.calculateL_),
    U_(ptf.U_),
    UMax_(ptf.UMax_),
    I_(ptf.I_),
    R_(ptf.R_),
    Lux_(ptf.Lux_),
    Lvx_(ptf.Lvx_),
    Lwx_(ptf.Lwx_),
    LuyToLuxRatio_(ptf.LuyToLuxRatio_),
    LuzToLuxRatio_(ptf.LuzToLuxRatio_),
    LvyToLvxRatio_(ptf.LvyToLvxRatio_),
    LvzToLvxRatio_(ptf.LvzToLvxRatio_),
    LwyToLwxRatio_(ptf.LwyToLwxRatio_),
    LwzToLwxRatio_(ptf.LwzToLwxRatio_),

    V0_(ptf.V0_),
    eddyDensity_(ptf.eddyDensity_),
    nEddy_(ptf.nEddy_),
    eddies_(ptf.eddies_),
    eddyShape_(ptf.eddyShape_),
    rndGen_(ptf.rndGen_),
    maxEddySize_(ptf.maxEddySize_),
    singleProc_(ptf.singleProc_)
{}


// * * * * * * * * * * * * * * * * Destructor  * * * * * * * * * * * * * * * //

Foam::syntheticEddyFvPatchVectorField::~
syntheticEddyFvPatchVectorField()
{}


// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

void Foam::syntheticEddyFvPatchVectorField::updateCoeffs()
{
    if (updated())
    {
        return;
    }

    if (curTimeIndex_ == -1)
    {
        initialisePatch();
        initialiseParameters();
        initialiseEddyBox();
        initialiseEddies();
    }

    if (curTimeIndex_ != db().time().timeIndex())
    {
        if (debug)
        {
            label n = eddies_.size();
            Info<< "Number of eddies: " << returnReduce(n, sumOp<label>())
                << endl;
        }

        const scalar deltaT = db().time().deltaTValue();

        // Move eddies using mean velocity
        convectEddies(deltaT);

        // Set velocity
        vectorField& U = *this;
        U = U_*patchNormal_;

        pointField Cf = (transform()&patch().Cf())-origin();

        // Apply normalisation coefficient
        const scalar c = Foam::sqrt(V0_)/Foam::sqrt(scalar(nEddy_));

        // In parallel, need to collect all eddies that will interact with
        // local faces

        if (singleProc_ || !Pstream::parRun())
        {
            U += c*transform_.T()&uFluctEddy(eddies_, Cf);
        }
        else
        {
            // Process local eddy contributions
            U += c*transform_.T()&uFluctEddy(eddies_, Cf);

            // Add contributions from overlapping eddies
            List<List<eddy>> overlappingEddies(Pstream::nProcs());
            calcOverlappingProcEddies(overlappingEddies);

            forAll(overlappingEddies, procI)
            {
                const List<eddy>& eddies = overlappingEddies[procI];

                if (eddies.size())
                {
                    //Pout<< "Applying " << eddies.size()
                    //    << " eddies from processor " << procI << endl;
                    U += c*transform_.T()&uFluctEddy(eddies, Cf);

                }
            }
        }

        // Re-scale to ensure correct flow rate
        scalar fCorr = gSum(U_*patch().magSf())/gSum(-U&patch().Sf());

        U *= fCorr;

        if (Pstream::master())
        {
            Info<< "mass flow correction coefficient: " << fCorr << endl;
        }

        curTimeIndex_ = db().time().timeIndex();
    }

    fixedValueFvPatchVectorField::updateCoeffs();
}


void Foam::syntheticEddyFvPatchVectorField::write(Ostream& os) const
{
    fvPatchField<vector>::write(os);
    writeEntry("value", os);

    os.writeKeyword("eddyDensity") << eddyDensity_ << token::END_STATEMENT << nl;
    os.writeKeyword("eddyShape") << eddyShape_ << token::END_STATEMENT << nl;
    os.writeKeyword("intersection") << intersection_ << token::END_STATEMENT << nl;
    os.writeKeyword("yOffset") << yOffset_ << token::END_STATEMENT << nl;
    os.writeKeyword("zOffset") << zOffset_ << token::END_STATEMENT << nl;
}


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

namespace Foam
{
   makePatchTypeField
   (
       fvPatchVectorField,
       syntheticEddyFvPatchVectorField
   );
}


// ************************************************************************* //
