/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     | Website:  https://openfoam.org
    \\  /    A nd           | Copyright (C) 2011-2018 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

\*---------------------------------------------------------------------------*/

#include "digitalFilterFvPatchVectorField.H"
#include "volFields.H"
#include "surfaceFields.H"
#include "addToRunTimeSelectionTable.H"
#include "mathematicalConstants.H"

// * * * * * * * * * * * * * * Static Data Members * * * * * * * * * * * * * //

Foam::scalar Foam::digitalFilterFvPatchVectorField::lengthRatioMin_ = 0.1;

// * * * * * * * * * * * * * Private Member Functions  * * * * * * * * * * * //

void Foam::digitalFilterFvPatchVectorField::initialisePatch()
{
    const vectorField nf(patch().nf());

    // Patch normal points into domain
    patchNormal_ = -gAverage(nf);

    // Check that patch is planar
    scalar error = max(magSqr(patchNormal_ + nf));

    if (error > SMALL)
    {
        WarningInFunction << "Patch " << patch().name() << " is not planar" << endl;
    }

    forAll (patchNormal_, label)
    {
        if (mag(patchNormal_[label]) <= SMALL)
        {
            patchNormal_[label] = 0;
        }
    }

    vector yDirection(vector::zero);
    vector zDirection(vector::zero);

    if (mag(intersection_) > 0)
    {
        intersection_ /= mag(intersection_);
        zDirection = patchNormal_^intersection_;

        if (mag(zDirection) == 0)
        {
            zDirection = vector(0,0,1);
        }
    }
    else
    {
        zDirection = vector(0,0,1);
    }

    yDirection = zDirection^patchNormal_;

    if (mag(intersection_) > 0)
    {
        vector eulerAngle(vector::zero);

        eulerAngle[0] = ::acos(vector(1,0,0)&intersection_);
        tensor T1 = tensor(::cos(eulerAngle[0]),::sin(eulerAngle[0]),0,-::sin(eulerAngle[0]),::cos(eulerAngle[0]),0,0,0,1);
        scalar sign = (T1&vector(1,0,0))&intersection_;

        if (sign < 0)
        {
            eulerAngle[0] = -eulerAngle[0];
            T1 = tensor(::cos(eulerAngle[0]),::sin(eulerAngle[0]),0,-::sin(eulerAngle[0]),::cos(eulerAngle[0]),0,0,0,1);
        }

        eulerAngle[1] = ::acos(vector(0,0,1)&zDirection);
        tensor T2 = tensor(1,0,0,0,::cos(eulerAngle[1]),::sin(eulerAngle[1]),0,-::sin(eulerAngle[1]),::cos(eulerAngle[1]));
        sign = (T2&vector(0,0,1))&zDirection;

        if (sign < 0)
        {
            eulerAngle[1] = -eulerAngle[1];
            T2 = tensor(1,0,0,0,::cos(eulerAngle[1]),::sin(eulerAngle[1]),0,-::sin(eulerAngle[1]),::cos(eulerAngle[1]));
        }
    
        eulerAngle[2] = ::acos(patchNormal_&intersection_);
        tensor T3 = tensor(::cos(eulerAngle[2]),::sin(eulerAngle[2]),0,-::sin(eulerAngle[2]),::cos(eulerAngle[2]),0,0,0,1);
        sign = (T3&intersection_)&patchNormal_;

        if (sign < 0)
        {
            eulerAngle[2] = -eulerAngle[2];
            T3 = tensor(::cos(eulerAngle[2]),::sin(eulerAngle[2]),0,-::sin(eulerAngle[2]),::cos(eulerAngle[2]),0,0,0,1);
        }
    
        transform_ = T3&(T2&T1);
    }
    else
    {
        scalar eulerAngle = ::acos(vector(1,0,0)&patchNormal_);
        tensor T1 = tensor(::cos(eulerAngle),::sin(eulerAngle),0,-::sin(eulerAngle),::cos(eulerAngle),0,0,0,1);
        scalar sign = (T1&vector(1,0,0))&patchNormal_;

        if (sign < 0)
        {
            eulerAngle = -eulerAngle;
            T1 = tensor(::cos(eulerAngle),::sin(eulerAngle),0,-::sin(eulerAngle),::cos(eulerAngle),0,0,0,1);
        }

        transform_ = T1;
    }

    forAll (transform_, label)
    {
        if (mag(transform_[label]) <= SMALL)
        {
            transform_[label] = 0;
        }
    }

    Info<< transform_ << endl;

    const fvBoundaryMesh& boundaryMesh = patch().boundaryMesh();
    const fvMesh& mesh = boundaryMesh.mesh();
    const faceList& fs = mesh.faces();
    const pointField& points_ = mesh.points();

    const fvPatch& p = patch();
    const polyPatch& pp = p.patch();

    label nPoints = 0;

    for (label facei = 0; facei<pp.size(); facei++)
    {
        const labelList& f = fs[facei+pp.start()];
        nPoints += f.size();
    }

    labelList pList(nPoints, 0);
    label pos = 0;

    for (label facei = 0; facei<pp.size(); facei++)
    {
        const labelList& f = fs[facei+pp.start()];

        for (label pi = 0; pi < f.size(); pi++)
        {
            pList[pi+pos] = f[pi];
        }

        pos += f.size();
    }

    labelList uniqueOrderList;
    uniqueOrder(pList, uniqueOrderList);

    labelList pUniqueList(uniqueOrderList.size(), 0);
    vectorField patchPoints(uniqueOrderList.size(), vector::zero);

    forAll(uniqueOrderList, label)
    {
        pUniqueList[label] = pList[uniqueOrderList[label]];
        patchPoints[label] = points_[pUniqueList[label]];
    }

    boundBox patchBounds(transform_&patchPoints);

    originOfLocalCoord_ = patchBounds.min();
    originOfLocalCoord_[1] += yOffset_;
    originOfLocalCoord_[2] += zOffset_;

    if (Pstream::master())
    {
        Info<< "local x-axis: " << patchNormal_ << endl;
        Info<< "local y-axis: " << yDirection << endl;
        Info<< "local z-axis: " << zDirection << endl;
        Info<< "global position of the origin of the local coordinate sytem: " 
            << (transform_.T()&originOfLocalCoord_) << endl;
        Info<< "coordinates tranform matrix: " << transform_ << endl;
    }

    // Set number of patch faces for each processor
    patchSize_[Pstream::myProcNo()] = patch().Cf().size();

    Pstream::gatherList(patchSize_);
    Pstream::scatterList(patchSize_);
}

void Foam::digitalFilterFvPatchVectorField::initialiseParameters()
{
    U_ = calculateOrRead<scalar>("U", inflowProperties_, calculateU_);
    I_ = calculateOrRead<symmTensor>("I", inflowProperties_, calculateI_);
    Lux_ = calculateOrRead<scalar>("Lux", inflowProperties_, calculateL_);
    Lvx_ = calculateOrRead<scalar>("Lvx", inflowProperties_, calculateL_);
    Lwx_ = calculateOrRead<scalar>("Lwx", inflowProperties_, calculateL_);

    const scalar deltaT = db().time().deltaTValue();

    forAll(Lux_, label)
    {
        if (Lux_[label] < U_[label]*deltaT)
        {
            Lux_[label] = U_[label]*deltaT;
        }

        if (Lvx_[label] < U_[label]*deltaT)
        {
            Lvx_[label] = U_[label]*deltaT;
        }

        if (Lwx_[label] < U_[label]*deltaT)
        {
            Lwx_[label] = U_[label]*deltaT;
        }
    }

    if (LuyToLuxRatio_ < lengthRatioMin_)
    {
        LuyToLuxRatio_ = lengthRatioMin_;
    }

    if (LuzToLuxRatio_ < lengthRatioMin_)
    {
        LuzToLuxRatio_ = lengthRatioMin_;
    }

    if (LvyToLvxRatio_ < lengthRatioMin_)
    {
        LvyToLvxRatio_ = lengthRatioMin_;
    }

    if (LvzToLvxRatio_ < lengthRatioMin_)
    {
        LvzToLvxRatio_ = lengthRatioMin_;
    }

    if (LwyToLwxRatio_ < lengthRatioMin_)
    {
        LwyToLwxRatio_ = lengthRatioMin_;
    }

    if (LwzToLwxRatio_ < lengthRatioMin_)
    {
        LwzToLwxRatio_ = lengthRatioMin_;
    }

    symmTensorField R_(U_*I_);

    forAll(R_, label)
    {
        R_[label].component(symmTensor::XX) = R_[label].component(symmTensor::XX)*R_[label].component(symmTensor::XX);
        R_[label].component(symmTensor::YY) = R_[label].component(symmTensor::YY)*R_[label].component(symmTensor::YY);
        R_[label].component(symmTensor::ZZ) = R_[label].component(symmTensor::ZZ)*R_[label].component(symmTensor::ZZ);
        R_[label].component(symmTensor::XY) = R_[label].component(symmTensor::XY)*R_[label].component(symmTensor::XY)*sign(I_[label].component(symmTensor::XY));
        R_[label].component(symmTensor::YZ) = R_[label].component(symmTensor::YZ)*R_[label].component(symmTensor::YZ)*sign(I_[label].component(symmTensor::YZ));
        R_[label].component(symmTensor::XZ) = R_[label].component(symmTensor::XZ)*R_[label].component(symmTensor::XZ)*sign(I_[label].component(symmTensor::XZ));
    }

    Lund_.replace(tensor::XX, sqrt(R_.component(symmTensor::XX)));
    Lund_.replace(tensor::YX, R_.component(symmTensor::XY)/Lund_.component(tensor::XX));
    Lund_.replace(tensor::ZX, R_.component(symmTensor::XZ)/Lund_.component(tensor::XX));
    Lund_.replace(tensor::YY, sqrt(R_.component(symmTensor::YY)-sqr(Lund_.component(tensor::YX))));
    Lund_.replace(tensor::ZY, (R_.component(symmTensor::YZ) - Lund_.component(tensor::YX)*Lund_.component(tensor::ZX) )/Lund_.component(tensor::YY));
    Lund_.replace(tensor::ZZ, sqrt(R_.component(symmTensor::ZZ) - sqr(Lund_.component(tensor::ZX))-sqr(Lund_.component(tensor::ZY))));
}

void Foam::digitalFilterFvPatchVectorField::initialiseVirtualGrid()
{
    // Set the origin and spacing of the virtual grid points
    boundBox patchBounds(transform_&patch().Cf());

    originOfVirtualGrid_ = patchBounds.min();

    delta_ = Foam::sqrt(gMin(patch().magSf()))/gridFactor_;

    scalar maxSpan = patchBounds.span().component(vector::Y);

    if (maxSpan < patchBounds.span().component(vector::Z))
    {
        maxSpan = patchBounds.span().component(vector::Z);
    }

    if (delta_ < maxSpan*minRelDelta_)
    {
        delta_ = maxSpan*minRelDelta_;
    }

    My_ = patchBounds.span().component(vector::Y)/delta_ + 1;
    Mz_ = patchBounds.span().component(vector::Z)/delta_ + 1;

    // Get the patch face centres from all processors
    vectorField fCentres = gatherProc(patch().Cf());
    fCentres = (transform_&fCentres)-originOfVirtualGrid_;

    // Sort the face centres and set the patch faces to virtual girds mapping
    facesToIndices_.setSize(fCentres.size(), -1);
    sortfaceCentres(fCentres, facesToIndices_);

    fCentres = vectorField(fCentres, facesToIndices_);

    // Set the virtual girds to patch faces mapping
    labelList inverseMapping(facesToIndices_);

    sortedOrder(facesToIndices_, inverseMapping);

    // Set the indices of virtual grid points
    yindices_.setSize(fCentres.size());
    zindices_.setSize(fCentres.size());

    forAll(fCentres, faceI)
    {
        scalar distY = fCentres[faceI].component(vector::Y);
        scalar distZ = fCentres[faceI].component(vector::Z);

        yindices_[faceI] = floor(distY/delta_);
        zindices_[faceI] = floor(distZ/delta_);

        scalar remY = distY - floor(distY/delta_) * delta_;
        scalar remZ = distZ - floor(distZ/delta_) * delta_;

        if (remY > delta_/2) 
        {
            yindices_[faceI] += 1;
        }

        if (remZ > delta_/2) 
        {
            zindices_[faceI] += 1;
        }        
    }

    // Set the indices to faces
    label start = 0;

    if (Pstream::myProcNo() > 0)
    {
        for (label i = 0; i < Pstream::myProcNo(); i++)
        {
            start = start + patchSize_[i];
        }
    }

    if (patchSize_[Pstream::myProcNo()] > 0)
    {
        indicesToFaces_ = SubList<label>(inverseMapping, patchSize_[Pstream::myProcNo()], start);
    }

    // Set the number of grids for each processsor
    indicesPerProc_ = 0;
    rest_ = 0;

    if (Pstream::master())
    {
        indicesPerProc_ = floor(scalar(fCentres.size())/(Pstream::nProcs()));
        rest_ = fCentres.size()-(indicesPerProc_*(Pstream::nProcs()));

        Info << nl << "Generating Inflow for " << fCentres.size() << " faces" << endl;
        Info << "Distributing Indices per Proc: " << indicesPerProc_ << endl;

        if (rest_ > 0)
        {
            Info << "First " << rest_ << " Procs will do +1 Indices" << nl << endl;
        }
    }

    Pstream::scatter(indicesPerProc_);
    Pstream::scatter(rest_);
}

void Foam::digitalFilterFvPatchVectorField::initialiseDigitalFilter()
{
    // Gather the length scale field from each processors
    scalarField Lux(gatherProc(Lux_), facesToIndices_);
    scalarField Lvx(gatherProc(Lvx_), facesToIndices_);
    scalarField Lwx(gatherProc(Lwx_), facesToIndices_);

    ny_.setSize(Lux.size());
    nz_.setSize(Lux.size());

    forAll(Lux, label)
    {
        ny_[label] = vector(round(LuyToLuxRatio_*Lux[label]/delta_),round(LvyToLvxRatio_*Lvx[label]/delta_),round(LwyToLwxRatio_*Lwx[label]/delta_))+vector::one;
        nz_[label] = vector(round(LuzToLuxRatio_*Lux[label]/delta_),round(LvzToLvxRatio_*Lvx[label]/delta_),round(LwzToLwxRatio_*Lwx[label]/delta_))+vector::one;
    }

    nyMax_ = gMax(ny_);
    nzMax_ = gMax(nz_);

    // Set size of virtual grid
    rndSize_.component(0) = (My_+nfK_*nyMax_.component(0))*(Mz_+nfK_*nzMax_.component(0));
    rndSize_.component(1) = (My_+nfK_*nyMax_.component(1))*(Mz_+nfK_*nzMax_.component(1));
    rndSize_.component(2) = (My_+nfK_*nyMax_.component(2))*(Mz_+nfK_*nzMax_.component(2));

    if (Pstream::master())
    {
        Info<< "Generating " << rndSize_.component(0)+rndSize_.component(1)+rndSize_.component(2) << " Random Numbers" << endl;
    }

    //For current processor, get start and end index in virtual list.
    label start;
    label size;

    if (Pstream::myProcNo() < rest_)
    {
        start = Pstream::myProcNo()*indicesPerProc_ + Pstream::myProcNo();
        size = indicesPerProc_+1;
    }
    else
    {
        start = Pstream::myProcNo()*indicesPerProc_ + rest_;
        size = indicesPerProc_;
    }

    //only fill element of current proc
    filterCoeffProc_u.setSize(size);
    filterCoeffProc_v.setSize(size);
    filterCoeffProc_w.setSize(size);

    //loop through all indices in one proc, and set filter kernel size and fill with 0.0
    for (label subI = 0; subI < size; subI++)
    {
        //index in full array
        label I = subI+start;

        filterCoeffProc_u[subI].setSize((nfK_*ny_[I].component(0)+1)*(nfK_*nz_[I].component(0)+1), 0.0);
        filterCoeffProc_v[subI].setSize((nfK_*ny_[I].component(1)+1)*(nfK_*nz_[I].component(1)+1), 0.0);
        filterCoeffProc_w[subI].setSize((nfK_*ny_[I].component(2)+1)*(nfK_*nz_[I].component(2)+1), 0.0);

        get2DFilterCoeff(filterCoeffProc_u[subI], ny_[I].component(0), nz_[I].component(0));
        get2DFilterCoeff(filterCoeffProc_v[subI], ny_[I].component(1), nz_[I].component(1));
        get2DFilterCoeff(filterCoeffProc_w[subI], ny_[I].component(2), nz_[I].component(2));
    }
}

void Foam::digitalFilterFvPatchVectorField::sortfaceCentres
(
    const vectorField& fCentres_,
    labelList& order_
)
{
    List<scalar> yCoordinate;
    yCoordinate.setSize(fCentres_.size());

    forAll(yCoordinate, i)
    {
        yCoordinate[i] = fCentres_[i].component(vector::Y);
    }

    List<label> yOrder;
    sortedOrder(yCoordinate, yOrder);

    sort(yCoordinate);

    List<label> unique;
    uniqueOrder(yCoordinate, unique);

    for (int i = 0; i < unique.size(); i++)
    {
        label size, start;

        if (i == 0)
        {
            size = unique[i] + 1;
            start = 0;
        }
        else
        {
            size = unique[i]-unique[i-1];
            start = unique[i-1] + 1;
        }

        List<scalar> zCoordinate(size, 0.0);

        for (int j = 0; j < size; j++)
        {
            zCoordinate[j] = fCentres_[yOrder[start+j]].component(vector::Z);
        }

        List<label> zOrder;
        sortedOrder(zCoordinate, zOrder);

        for (int j = 0; j < size; j++)
        {
            order_[start+j] = yOrder[start+zOrder[j]];
        }
    }
}


inline Foam::label 
Foam::digitalFilterFvPatchVectorField::get1DIndex(label x, label y, label yDim)
{
    return x * yDim + y;
}


void Foam::digitalFilterFvPatchVectorField::get1DFilterCoeff(scalarList& b, label n)
{
    const scalar pi = constant::mathematical::pi;

    if (n == 0)
    {
        b.setSize(1, 0.0);
    }
    else
    {
        scalar sum = 0.0;

        label N = nfK_*n/2;

        b.setSize(2*N+1);

        for (label k = 0; k < 2*N+1; k++)
        {
            if (filterShape_ == "exponential")
            {
                b[k] = Foam::exp(-fabs(1.0*(k-N)/n));
            }
            else if (filterShape_ == "gaussian")
            {
                b[k] = Foam::exp(-pi*Foam::sqr(scalar(k-N))/(2.0*Foam::sqr(scalar(n))));
            }
            else
            {
                Info << "filter coefficient function" << filterShape_ << " does not exist (ERROR)" << endl;
            }

            sum += b[k]*b[k];
        }

        sum = Foam::sqrt(sum);
        b = b/sum;
    }
}

void Foam::digitalFilterFvPatchVectorField::get2DFilterCoeff(scalarList& filter,label ny, label nz)
{
    scalarList by;
    scalarList bz;

    get1DFilterCoeff(by, ny);
    get1DFilterCoeff(bz, nz);

    for (label i = 0; i < nfK_*ny+1; i++)
    {
        for (label j = 0; j < nfK_*nz+1; j++)
        {
            filter[get1DIndex(i, j, nfK_*nz+1)] = by[i]*bz[j];
        }
    }
}

Foam::scalarField
Foam::digitalFilterFvPatchVectorField::getRandomField(label totalSize)
{
    List<scalarField> virtualRandomFieldProc;

    virtualRandomFieldProc.setSize(Pstream::nProcs());

    label size = floor(totalSize/Pstream::nProcs());
    label rest = totalSize-size*Pstream::nProcs();

    if (Pstream::myProcNo() < rest)
    {
        virtualRandomFieldProc[Pstream::myProcNo()].setSize(size+1);
    }
    else
    {
        virtualRandomFieldProc[Pstream::myProcNo()].setSize(size);
    }

    forAll (virtualRandomFieldProc[Pstream::myProcNo()], i)
    {
        virtualRandomFieldProc[Pstream::myProcNo()][i] = rndGen_.scalarNormal();
    }

    Pstream::gatherList(virtualRandomFieldProc);
    Pstream::scatterList(virtualRandomFieldProc);

    return ListListOps::combine<scalarField>(virtualRandomFieldProc, accessOp<scalarField>());
}

void Foam::digitalFilterFvPatchVectorField::spatialCorr()
{
    scalarField virtualRandomField_u = getRandomField(rndSize_.component(0));
    scalarField virtualRandomField_v = getRandomField(rndSize_.component(1));
    scalarField virtualRandomField_w = getRandomField(rndSize_.component(2));

    label start, size;

    if (Pstream::myProcNo() < rest_)
    {
        start = Pstream::myProcNo()*indicesPerProc_ + Pstream::myProcNo();
        size = indicesPerProc_ + 1;
    }
    else
    {
        start = Pstream::myProcNo()*indicesPerProc_ + rest_;
        size = indicesPerProc_;
    }
    
    List<vectorField> virtualFilteredFieldProc;

    virtualFilteredFieldProc.setSize(Pstream::nProcs());
    virtualFilteredFieldProc[Pstream::myProcNo()].setSize(size, vector::zero);

    labelVector yOffset = nfK_*nyMax_/2;
    labelVector zOffset = nfK_*nzMax_/2;

    forAll (virtualFilteredFieldProc[Pstream::myProcNo()], subI)
    {
        label I = subI+start;

        label i = yindices_[I]; // i = yindices on virtual Grid
        label j = zindices_[I]; // j = zindices on virtual Grid

        vector u = vector::zero;

        for (label ii = 0; ii < nfK_*ny_[I].component(0)+1; ii++)
        {
            label start_rnd = get1DIndex
            (
                i+yOffset.component(0)-nfK_/2*ny_[I].component(0)+ii,
                j+zOffset.component(0)-nfK_/2*nz_[I].component(0),
                Mz_+nfK_*nzMax_.component(0)
            );

            label size_rnd = nfK_*nz_[I].component(0)+1;
            label start_filt = get1DIndex(ii, 0, nfK_*nz_[I].component(0)+1);

            scalarField rnd = SubField<scalar>(virtualRandomField_u, size_rnd, start_rnd);
            scalarField filt = SubField<scalar>(filterCoeffProc_u[subI], size_rnd, start_filt);

            u.component(0) += sumProd(rnd,filt);
        }

        for (label ii = 0; ii < nfK_*ny_[I].component(1)+1; ii++)
        {
            label start_rnd = get1DIndex
            (
                i+yOffset.component(1)-nfK_/2*ny_[I].component(1)+ii,
                j+zOffset.component(1)-nfK_/2*nz_[I].component(1),
                Mz_+nfK_*nzMax_.component(1)
            );

            label size_rnd = nfK_*nz_[I].component(1)+1;
            label start_filt = get1DIndex(ii, 0, nfK_*nz_[I].component(1)+1);

            scalarField rnd = SubField<scalar>(virtualRandomField_v, size_rnd, start_rnd);
            scalarField filt = SubField<scalar>(filterCoeffProc_v[subI], size_rnd, start_filt);

            u.component(1) += sumProd(rnd,filt);
        }

        for (label ii = 0; ii < nfK_*ny_[I].component(2)+1; ii++)
        {
            label start_rnd = get1DIndex
            (
                i+yOffset.component(2)-nfK_/2*ny_[I].component(2)+ii,
                j+zOffset.component(2)-nfK_/2*nz_[I].component(2),
                Mz_+nfK_*nzMax_.component(2)
            );

            label size_rnd = nfK_*nz_[I].component(2)+1;
            label start_filt = get1DIndex(ii, 0, nfK_*nz_[I].component(2)+1);

            scalarField rnd = SubField<scalar>(virtualRandomField_w, size_rnd, start_rnd);
            scalarField filt = SubField<scalar>(filterCoeffProc_w[subI], size_rnd, start_filt);

            u.component(2) += sumProd(rnd,filt);
        }

        virtualFilteredFieldProc[Pstream::myProcNo()][subI] = u;
    }

    Pstream::gatherList(virtualFilteredFieldProc);
    Pstream::scatterList(virtualFilteredFieldProc);

    vectorField virtualFilteredField = ListListOps::combine<vectorField>(virtualFilteredFieldProc, accessOp<vectorField>());

    uFluctFiltered_ = vectorField(virtualFilteredField, indicesToFaces_);
}

void Foam::digitalFilterFvPatchVectorField::temporalCorr()
{
    scalar dt = db().time().deltaT().value();

    forAll(uFluctTemporal_, faceI)
    {
        vector T = vector(Lux_[faceI],Lvx_[faceI],Lwx_[faceI])/U_[faceI];

        for (label ii = 0; ii < 2; ii++)
        {
            uFluctTemporal_[faceI].component(ii) = uFluctTemporalOld_[faceI].component(ii)*Foam::exp(-dt/T.component(ii))
                                                 + uFluctFiltered_[faceI].component(ii)*Foam::sqrt(1.0-Foam::exp(-2.0*dt/T.component(ii)));
        }
    }

    uFluctTemporalOld_ = uFluctTemporal_;
}


// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

Foam::digitalFilterFvPatchVectorField::
digitalFilterFvPatchVectorField
(
    const fvPatch& p,
    const DimensionedField<vector, volMesh>& iF
)
:
    fixedValueFvPatchVectorField(p, iF),

    curTimeIndex_(-1),
    patchSize_(Pstream::nProcs(), 0),
    patchNormal_(vector::zero),
    intersection_(vector::zero),
    originOfLocalCoord_(vector::zero),
    yOffset_(0),
    zOffset_(0),
    transform_(tensor::I),
    uFluctFiltered_(p.size(), pTraits<vector>::zero),
    uFluctTemporalOld_(p.size(), pTraits<vector>::zero),
    uFluctTemporal_(p.size(), pTraits<vector>::zero),

    inflowProperties_(),
    calculateU_(false),
    calculateI_(false),
    calculateL_(false),
    U_(p.size(), 0.0),
    I_(p.size(), pTraits<symmTensor>::zero),
    Lux_(p.size(), 0.0),
    Lvx_(p.size(), 0.0),
    Lwx_(p.size(), 0.0),
    LuyToLuxRatio_(1.0),
    LuzToLuxRatio_(1.0),
    LvyToLvxRatio_(1.0),
    LvzToLvxRatio_(1.0),
    LwyToLwxRatio_(1.0),
    LwzToLwxRatio_(1.0),
    Lund_(p.size(), pTraits<tensor>::zero),

    isInitialized_(false),
    gridFactor_(1.0),
    minRelDelta_(0.0),
    originOfVirtualGrid_(vector::zero),
    My_(0),
    Mz_(0),
    delta_(0),
    ny_(),
    nz_(),
    nyMax_(vector::zero),
    nzMax_(vector::zero),
    nfK_(4),
    yindices_(),
    zindices_(),

    indicesPerProc_(0),
    rest_(0),
    facesToIndices_(),
    indicesToFaces_(),

    rndGen_((Pstream::myProcNo()+1)*time(NULL)),
    filterShape_("exponential"),
    rndSize_(vector::zero),
    filterCoeffProc_u(),
    filterCoeffProc_v(),
    filterCoeffProc_w()
{}


Foam::digitalFilterFvPatchVectorField::
digitalFilterFvPatchVectorField
(
    const fvPatch& p,
    const DimensionedField<vector, volMesh>& iF,
    const dictionary& dict
)
:
    fixedValueFvPatchVectorField(p, iF, dict),

    curTimeIndex_(-1),
    patchSize_(Pstream::nProcs(), 0),
    patchNormal_(vector::zero),
    intersection_(dict.lookupOrDefault<vector>("intersection", vector(0,0,0))),
    originOfLocalCoord_(vector::zero),
    yOffset_(dict.lookupOrDefault<scalar>("yOffset", 0.0)),
    zOffset_(dict.lookupOrDefault<scalar>("zOffset", 0.0)),
    transform_(tensor::I),
    uFluctFiltered_(p.size(), pTraits<vector>::zero),
    uFluctTemporalOld_(p.size(), pTraits<vector>::zero),
    uFluctTemporal_(p.size(), pTraits<vector>::zero),

    inflowProperties_
    (
        IOdictionary
        (
            IOobject
            (
                "inflowProperties",
                internalField().mesh().time().constant(),
                internalField().mesh(),
                IOobject::MUST_READ_IF_MODIFIED,
                IOobject::NO_WRITE,
                false
            )
        )
    ),
    calculateU_(false),
    calculateI_(false),
    calculateL_(false),
    U_(p.size(), 0.0),
    I_(p.size(), pTraits<symmTensor>::zero),
    Lux_(p.size(), 0.0),
    Lvx_(p.size(), 0.0),
    Lwx_(p.size(), 0.0),
    LuyToLuxRatio_(inflowProperties_.lookupOrDefault<scalar>("LuyToLuxRatio", 1.0)),
    LuzToLuxRatio_(inflowProperties_.lookupOrDefault<scalar>("LuzToLuxRatio", 1.0)),
    LvyToLvxRatio_(inflowProperties_.lookupOrDefault<scalar>("LvyToLvxRatio", 1.0)),
    LvzToLvxRatio_(inflowProperties_.lookupOrDefault<scalar>("LvzToLvxRatio", 1.0)),
    LwyToLwxRatio_(inflowProperties_.lookupOrDefault<scalar>("LwyToLwxRatio", 1.0)),
    LwzToLwxRatio_(inflowProperties_.lookupOrDefault<scalar>("LwzToLwxRatio", 1.0)),
    Lund_(p.size(), pTraits<tensor>::zero),

    isInitialized_(false),
    gridFactor_(dict.lookupOrDefault<scalar>("gridFactor", 1.0)),
    minRelDelta_(dict.lookupOrDefault<scalar>("minRelDelta", 0.0)),
    originOfVirtualGrid_(vector::zero),
    My_(0),
    Mz_(0),
    delta_(0),
    ny_(),
    nz_(),
    nyMax_(vector::zero),
    nzMax_(vector::zero),
    nfK_(dict.lookupOrDefault<label>("filterFactor", 4)),
    yindices_(),
    zindices_(),

    indicesPerProc_(0),
    rest_(0),
    facesToIndices_(),
    indicesToFaces_(),

    rndGen_((Pstream::myProcNo()+1)*time(NULL)),
    filterShape_(dict.lookupOrDefault<word>("shape", "exponential")),
    rndSize_(vector::zero),
    filterCoeffProc_u(),
    filterCoeffProc_v(),
    filterCoeffProc_w()
{}


Foam::digitalFilterFvPatchVectorField::
digitalFilterFvPatchVectorField
(
    const digitalFilterFvPatchVectorField& ptf,
    const fvPatch& p,
    const DimensionedField<vector, volMesh>& iF,
    const fvPatchFieldMapper& mapper
)
:
    fixedValueFvPatchVectorField(ptf, p, iF, mapper),

    curTimeIndex_(ptf.curTimeIndex_),
    patchSize_(ptf.patchSize_),
    patchNormal_(ptf.patchNormal_),
    intersection_(ptf.intersection_),
    originOfLocalCoord_(ptf.originOfLocalCoord_),
    yOffset_(ptf.yOffset_),
    zOffset_(ptf.zOffset_),
    transform_(ptf.transform_),
    uFluctFiltered_(ptf.uFluctFiltered_),
    uFluctTemporalOld_(ptf.uFluctTemporalOld_),
    uFluctTemporal_(ptf.uFluctTemporal_),

    inflowProperties_(ptf.inflowProperties_),
    calculateU_(ptf.calculateU_),
    calculateI_(ptf.calculateI_),
    calculateL_(ptf.calculateL_),
    U_(ptf.U_),
    I_(ptf.I_),
    Lux_(ptf.Lux_),
    Lvx_(ptf.Lvx_),
    Lwx_(ptf.Lwx_),
    LuyToLuxRatio_(ptf.LuyToLuxRatio_),
    LuzToLuxRatio_(ptf.LuzToLuxRatio_),
    LvyToLvxRatio_(ptf.LvyToLvxRatio_),
    LvzToLvxRatio_(ptf.LvzToLvxRatio_),
    LwyToLwxRatio_(ptf.LwyToLwxRatio_),
    LwzToLwxRatio_(ptf.LwzToLwxRatio_),
    Lund_(ptf.Lund_),

    isInitialized_(ptf.isInitialized_),
    gridFactor_(ptf.gridFactor_),
    minRelDelta_(ptf.minRelDelta_),
    originOfVirtualGrid_(ptf.originOfVirtualGrid_),
    My_(ptf.My_),
    Mz_(ptf.Mz_),
    delta_(ptf.delta_),
    ny_(ptf.ny_),
    nz_(ptf.nz_),
    nyMax_(ptf.nyMax_),
    nzMax_(ptf.nzMax_),
    nfK_(ptf.nfK_),
    yindices_(ptf.yindices_),
    zindices_(ptf.zindices_),

    indicesPerProc_(ptf.indicesPerProc_),
    rest_(ptf.rest_),
    facesToIndices_(ptf.facesToIndices_),
    indicesToFaces_(ptf.indicesToFaces_),

    rndGen_(ptf.rndGen_),
    filterShape_(ptf.filterShape_),
    rndSize_(ptf.rndSize_),
    filterCoeffProc_u(ptf.filterCoeffProc_u),
    filterCoeffProc_v(ptf.filterCoeffProc_v),
    filterCoeffProc_w(ptf.filterCoeffProc_w)
{}


Foam::digitalFilterFvPatchVectorField::
digitalFilterFvPatchVectorField
(
    const digitalFilterFvPatchVectorField& ptf
)
:
    fixedValueFvPatchVectorField(ptf),

    curTimeIndex_(ptf.curTimeIndex_),
    patchSize_(ptf.patchSize_),
    patchNormal_(ptf.patchNormal_),
    intersection_(ptf.intersection_),
    originOfLocalCoord_(ptf.originOfLocalCoord_),
    yOffset_(ptf.yOffset_),
    zOffset_(ptf.zOffset_),
    transform_(ptf.transform_),
    uFluctFiltered_(ptf.uFluctFiltered_),
    uFluctTemporalOld_(ptf.uFluctTemporalOld_),
    uFluctTemporal_(ptf.uFluctTemporal_),

    inflowProperties_(ptf.inflowProperties_),
    calculateU_(ptf.calculateU_),
    calculateI_(ptf.calculateI_),
    calculateL_(ptf.calculateL_),
    U_(ptf.U_),
    I_(ptf.I_),
    Lux_(ptf.Lux_),
    Lvx_(ptf.Lvx_),
    Lwx_(ptf.Lwx_),
    LuyToLuxRatio_(ptf.LuyToLuxRatio_),
    LuzToLuxRatio_(ptf.LuzToLuxRatio_),
    LvyToLvxRatio_(ptf.LvyToLvxRatio_),
    LvzToLvxRatio_(ptf.LvzToLvxRatio_),
    LwyToLwxRatio_(ptf.LwyToLwxRatio_),
    LwzToLwxRatio_(ptf.LwzToLwxRatio_),
    Lund_(ptf.Lund_),

    isInitialized_(ptf.isInitialized_),
    gridFactor_(ptf.gridFactor_),
    minRelDelta_(ptf.minRelDelta_),
    originOfVirtualGrid_(ptf.originOfVirtualGrid_),
    My_(ptf.My_),
    Mz_(ptf.Mz_),
    delta_(ptf.delta_),
    ny_(ptf.ny_),
    nz_(ptf.nz_),
    nyMax_(ptf.nyMax_),
    nzMax_(ptf.nzMax_),
    nfK_(ptf.nfK_),
    yindices_(ptf.yindices_),
    zindices_(ptf.zindices_),

    indicesPerProc_(ptf.indicesPerProc_),
    rest_(ptf.rest_),
    facesToIndices_(ptf.facesToIndices_),
    indicesToFaces_(ptf.indicesToFaces_),

    rndGen_(ptf.rndGen_),
    filterShape_(ptf.filterShape_),
    rndSize_(ptf.rndSize_),
    filterCoeffProc_u(ptf.filterCoeffProc_u),
    filterCoeffProc_v(ptf.filterCoeffProc_v),
    filterCoeffProc_w(ptf.filterCoeffProc_w)
{}


Foam::digitalFilterFvPatchVectorField::
digitalFilterFvPatchVectorField
(
    const digitalFilterFvPatchVectorField& ptf,
    const DimensionedField<vector, volMesh>& iF
)
:
    fixedValueFvPatchVectorField(ptf, iF),

    curTimeIndex_(ptf.curTimeIndex_),
    patchSize_(ptf.patchSize_),
    patchNormal_(ptf.patchNormal_),
    intersection_(ptf.intersection_),
    originOfLocalCoord_(ptf.originOfLocalCoord_),
    yOffset_(ptf.yOffset_),
    zOffset_(ptf.zOffset_),
    transform_(ptf.transform_),
    uFluctFiltered_(ptf.uFluctFiltered_),
    uFluctTemporalOld_(ptf.uFluctTemporalOld_),
    uFluctTemporal_(ptf.uFluctTemporal_),

    inflowProperties_(ptf.inflowProperties_),
    calculateU_(ptf.calculateU_),
    calculateI_(ptf.calculateI_),
    calculateL_(ptf.calculateL_),
    U_(ptf.U_),
    I_(ptf.I_),
    Lux_(ptf.Lux_),
    Lvx_(ptf.Lvx_),
    Lwx_(ptf.Lwx_),
    LuyToLuxRatio_(ptf.LuyToLuxRatio_),
    LuzToLuxRatio_(ptf.LuzToLuxRatio_),
    LvyToLvxRatio_(ptf.LvyToLvxRatio_),
    LvzToLvxRatio_(ptf.LvzToLvxRatio_),
    LwyToLwxRatio_(ptf.LwyToLwxRatio_),
    LwzToLwxRatio_(ptf.LwzToLwxRatio_),
    Lund_(ptf.Lund_),

    isInitialized_(ptf.isInitialized_),
    gridFactor_(ptf.gridFactor_),
    minRelDelta_(ptf.minRelDelta_),
    originOfVirtualGrid_(ptf.originOfVirtualGrid_),
    My_(ptf.My_),
    Mz_(ptf.Mz_),
    delta_(ptf.delta_),
    ny_(ptf.ny_),
    nz_(ptf.nz_),
    nyMax_(ptf.nyMax_),
    nzMax_(ptf.nzMax_),
    nfK_(ptf.nfK_),
    yindices_(ptf.yindices_),
    zindices_(ptf.zindices_),

    indicesPerProc_(ptf.indicesPerProc_),
    rest_(ptf.rest_),
    facesToIndices_(ptf.facesToIndices_),
    indicesToFaces_(ptf.indicesToFaces_),

    rndGen_(ptf.rndGen_),
    filterShape_(ptf.filterShape_),
    rndSize_(ptf.rndSize_),
    filterCoeffProc_u(ptf.filterCoeffProc_u),
    filterCoeffProc_v(ptf.filterCoeffProc_v),
    filterCoeffProc_w(ptf.filterCoeffProc_w)
{}


// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

void Foam::digitalFilterFvPatchVectorField::updateCoeffs()
{
    if (updated())
    {
        return;
    }

    //initialize virtual grid points
    if(!isInitialized_)
    {
        initialisePatch();
        initialiseParameters();
        initialiseVirtualGrid();
        initialiseDigitalFilter();
        spatialCorr();
        uFluctTemporalOld_ = uFluctFiltered_;
        isInitialized_ = true;
    }

    if (curTimeIndex_ != this->db().time().timeIndex())
    {
        Info<< "updating velocity at Time = " << db().time().value() << endl;

        curTimeIndex_ = db().time().timeIndex();

        // Filter random field
        spatialCorr();

        // create new temporally correlated slice
        temporalCorr();

        // Set final velocity field
        vectorField& U = *this;
        U = (U_*patchNormal_) + (transform_.T()&(Lund_&uFluctTemporal_));

        // Re-scale to ensure correct flow rate
        scalar fCorr = gSum(U_*patch().magSf())/gSum(-U&patch().Sf());

        if (Pstream::master())
        {
            Info<< "mass flow correction coefficient: " << fCorr << endl;
        }

        U *= fCorr;

    }

    fixedValueFvPatchVectorField::updateCoeffs();
}


void Foam::digitalFilterFvPatchVectorField::write(Ostream& os) const
{
    fvPatchVectorField::write(os);
    writeEntry("value", os);

    os.writeKeyword("gridFactor") << gridFactor_ << token::END_STATEMENT << nl;
    os.writeKeyword("filterShape") << filterShape_ << token::END_STATEMENT << nl;
    os.writeKeyword("filterFactor") << nfK_ << token::END_STATEMENT << nl;
    os.writeKeyword("minRelDelta") << minRelDelta_ << token::END_STATEMENT << nl;
    os.writeKeyword("intersection") << intersection_ << token::END_STATEMENT << nl;
    os.writeKeyword("yOffset") << yOffset_ << token::END_STATEMENT << nl;
    os.writeKeyword("zOffset") << zOffset_ << token::END_STATEMENT << nl;
}


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

namespace Foam
{
    makePatchTypeField
    (
        fvPatchVectorField,
        digitalFilterFvPatchVectorField
    );
}

// ************************************************************************* //
